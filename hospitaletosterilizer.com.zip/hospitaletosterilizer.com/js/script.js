
$('.btn-default').on('click',function(){
	$('.default-menu').slideToggle()
	$('.dropdown-overlay').show()
  });
  $('.dropdown-overlay').on('click',function(){
	$('.default-menu').hide(); 
	$(this).hide();
  });
  
  $('.btn-danger').on('click',function(){
	$('.slide-menu').slideToggle();
	$('.dropdown-overlay').show();
  })
  $('.dropdown-overlay').on('click',function(){
	$('.slide-menu').hide();
	$(this).hide();
  })


//  slider
$(document).ready(function() {
    $(".slider-1").slick({
        infinite: true,
        autoplay: true,
        autoplaySpeed: 1500,
        speed: 300,
        slidesToShow: 5,
        nextArrow: ".arr-next",
        prevArrow: ".arr-prev",
        slidesToScroll: 1,
        responsive: [{
                breakpoint: 1099,
                settings: {
                    slidesToShow: 4,
                    slidesToScroll: 1,
                    infinite: true,

                },
            }, {
                breakpoint: 1024,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 2,
                    infinite: true,

                },
            }, {
                breakpoint: 600,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1,
                },
            }, {
                breakpoint: 480,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1,
                },
            },
            // You can unslick at a given breakpoint now by adding:
            // settings: "unslick"
            // instead of a settings object
        ],
    });
});




// $(document).ready(function() {
//     $(".slider").slick({
//         slidesToShow: 4.5,
// 	slidesToScroll: 1,
// 	infinite: false,
//         nextArrow: ".arr-next",
//         prevArrow: ".arr-prev",
//         slidesToScroll: 4,
//         responsive: [{
//                 breakpoint: 1399,
//                 settings: {
//                     slidesToShow: 4.5,
//                     slidesToScroll: 1,
//                 },
//             },
//             {
//                 breakpoint: 1299,
//                 settings: {
//                     slidesToShow:4.5,
//                     slidesToScroll: 1,
//                 },
//             },
//             {
//                 breakpoint: 1099,
//                 settings: {
//                     slidesToShow: 4.5,
//                     slidesToScroll: 1,
//                 },
//             }, {
//                 breakpoint: 1024,
//                 settings: {
//                     slidesToShow: 3.5,
//                     slidesToScroll: 2,
//                 },
//             }, {
//                 breakpoint: 600,
//                 settings: {
//                     slidesToShow: 2.5,
//                     slidesToScroll: 1,
//                 },
//             }, {
//                 breakpoint: 480,
//                 settings: {
//                     slidesToShow: 1.5,
//                     slidesToScroll: 1,
//                 },
//             },
//             // You can unslick at a given breakpoint now by adding:
//             // settings: "unslick"
//             // instead of a settings object
//         ],
//     });
// });


$(document).ready(function () {
	$(".slider-2").slick({
		slidesToShow: 4.5,
		slidesToScroll: 1,
		infinite: false,
		nextArrow: ".pro-next",
		prevArrow: ".pro-prev",
		slidesToScroll: 4,
		responsive: [{
			breakpoint: 1099,
			settings: {
				slidesToShow: 3,
				slidesToScroll: 1,
				infinite: true,

			},
		}, {
			breakpoint: 1024,
			settings: {
				slidesToShow: 3,
				slidesToScroll: 2,
				infinite: true,

			},
		}, {
			breakpoint: 600,
			settings: {
				slidesToShow: 1,
				slidesToScroll: 1,
			},
		}, {
			breakpoint: 480,
			settings: {
				slidesToShow: 1,
				slidesToScroll: 1,
			},
		},
			// You can unslick at a given breakpoint now by adding:
			// settings: "unslick"
			// instead of a settings object
		],
	});
});

$(document).ready(function () {
	$(".slider-1").slick({
	  slidesToShow: 2.8,
	  slidesToScroll: 1,
	  infinite: false,
	  nextArrow: ".arr-n",
	  prevArrow: ".arr-p",
	  slidesToScroll: 2,
	  responsive: [
	  {
		breakpoint: 1499,
		settings: {
		  slidesToShow: 2.5,
		  slidesToScroll: 1,
		  infinite: true,

		},
	  },
	  {
		breakpoint: 1099,
		settings: {
		  slidesToShow: 2.5,
		  slidesToScroll: 1,
		  infinite: true,

		},
	  }, {
		breakpoint: 1024,
		settings: {
		  slidesToShow: 2.5,
		  slidesToScroll: 2,
		  infinite: true,

		},
	  }, {
		breakpoint: 600,
		settings: {
		  slidesToShow: 2.5,
		  slidesToScroll: 1,
		},
	  }, {
		breakpoint: 480,
		settings: {
		  slidesToShow: 1.5,
		  slidesToScroll: 1,
		},
	  },
		// You can unslick at a given breakpoint now by adding:
		// settings: "unslick"
		// instead of a settings object
	  ],
	});
  });


  $(document).ready(function() {
	$(".slider-2").slick({
		slidesToShow: 4.5,
	slidesToScroll: 1,
	infinite: false,
		nextArrow: ".pro-next",
		prevArrow: ".pro-prev",
		slidesToScroll: 4,
		responsive: [{
				breakpoint: 1099,
				settings: {
					slidesToShow: 3,
					slidesToScroll: 1,
					infinite: true,

				},
			}, {
				breakpoint: 1024,
				settings: {
					slidesToShow: 3,
					slidesToScroll: 2,
					infinite: true,

				},
			}, {
				breakpoint: 600,
				settings: {
					slidesToShow: 1,
					slidesToScroll: 1,
				},
			}, {
				breakpoint: 480,
				settings: {
					slidesToShow: 1,
					slidesToScroll: 1,
				},
			},
			// You can unslick at a given breakpoint now by adding:
			// settings: "unslick"
			// instead of a settings object
		],
	});
});
(function() {

	window.addEventListener('scroll', function () {
		const navbar = document.querySelector('.header');
		if (window.scrollY > 50) {
		  navbar.classList.add('scrolled');
		} else {
		  navbar.classList.remove('scrolled');
		}
	  });
  "use strict";
  


  window.addEventListener('scroll', function () {
		const navbar = document.querySelector('.header');
		if (window.scrollY > 50) {
		  navbar.classList.add('scrolled');
		} else {
		  navbar.classList.remove('scrolled');
		}
	  });
  "use strict";
  /**
   * Apply .scrolled class to the body as the page is scrolled down
   */
  function toggleScrolled() {
    const selectBody = document.querySelector('body');
    const selectHeader = document.querySelector('#header');
    if (!selectHeader.classList.contains('scroll-up-sticky') && !selectHeader.classList.contains('sticky-top') && !selectHeader.classList.contains('fixed-top')) return;
    window.scrollY > 100 ? selectBody.classList.add('scrolled') : selectBody.classList.remove('scrolled');
  }

  document.addEventListener('scroll', toggleScrolled);
  window.addEventListener('load', toggleScrolled);

  /**
   * Mobile nav toggle
   */
  const mobileNavToggleBtn = document.querySelector('.mobile-nav-toggle');

  function mobileNavToogle() {
    document.querySelector('body').classList.toggle('mobile-nav-active');
    mobileNavToggleBtn.classList.toggle('bi-list');
    mobileNavToggleBtn.classList.toggle('bi-x');
  }
  mobileNavToggleBtn.addEventListener('click', mobileNavToogle);


  document.querySelectorAll('.navmenu .toggle-dropdown').forEach(navmenu => {
    navmenu.addEventListener('click', function(e) {
      e.preventDefault();
      this.parentNode.classList.toggle('active');
      this.parentNode.nextElementSibling.classList.toggle('dropdown-active');
      e.stopImmediatePropagation();
    });
  });

  
})();





let gallery_control_option = document.querySelectorAll('.gallery_control_option');
	let nature = document.querySelectorAll('.nature');
	let people = document.querySelectorAll('.people');
	let animals = document.querySelectorAll('.animals');
	let home = document.querySelectorAll('.home');
	let orientation=document.getElementById('orientation');
	let any = document.getElementById('any');
	let landscape=document.getElementById('landscape');
	let portrait = document.getElementById('portrait');
	let nature_landscape = document.querySelectorAll('.nature_landscape');
	let nature_portrait = document.querySelectorAll('.nature_portrait');
	let people_landscape = document.querySelectorAll('.people_landscape');
	let people_portrait = document.querySelectorAll('.people_portrait');
	let animals_landscape = document.querySelectorAll('.animals_landscape');
	let animals_portrait = document.querySelectorAll('.animals_portrait');
	let home_landscape = document.querySelectorAll('.home_landscape');
	let home_portrait = document.querySelectorAll('.home_portrait');
	let orientation_option_wrapper=document.getElementById('orientation_option_wrapper');
	let orientation_status=0;
	let orientation_option = document.querySelectorAll('.orientation_option');
	let check = document.querySelectorAll('.check');
	let current_display="nature";
	highlight_active(0,1,2,3);

	// gallery filter menu
	for(i=0;i< gallery_control_option.length;i++){
		gallery_control_option[0].onclick=function(){
			filter_gallery(nature,people,animals,home);
			highlight_active(0,1,2,3);
			current_display="nature";
			display_check(0,1,2);
			orientation_option_wrapper.style.display="none";
			orientation.style.color="#4a4a4a";
			orientation.innerHTML="Any Orientation";
		}
		gallery_control_option[1].onclick=function(){
			filter_gallery(people,nature,animals,home);
			highlight_active(1,0,2,3);
			current_display="people";
			display_check(0,1,2);
			orientation_option_wrapper.style.display="none";
			orientation.style.color="#4a4a4a";
			orientation.innerHTML="Any Orientation";
		}
		gallery_control_option[2].onclick=function(){
			filter_gallery(animals,nature,people,home);
			highlight_active(2,1,0,3);
			current_display="animals";
			display_check(0,1,2);
			orientation_option_wrapper.style.display="none";
			orientation.style.color="#4a4a4a";
			orientation.innerHTML="Any Orientation";
		}
		gallery_control_option[3].onclick=function(){
			filter_gallery(home,animals,nature,people);
			highlight_active(3,1,2,0);
			current_display="home";
			display_check(0,1,2);
			orientation_option_wrapper.style.display="none";
			orientation.style.color="#4a4a4a";
			orientation.innerHTML="Any Orientation";
		}
	}
	
	// display orientation dropdown
	orientation.onclick=function(){
		if (orientation_status==0) {
			orientation_status=1;
			orientation_option_wrapper.style.display="block";
		}else{
			orientation_status=0;
			orientation_option_wrapper.style.display="none";
		}
	}

	// orientation option default
	display_check(0,1,2);
	orientation.innerHTML="Any Orientation";
	
	// filter gallery
	function filter_gallery($display,$hide,$hide2,$hide3){
		for(i=0;i<$display.length;i++){
	 		$display[i].style.display="block";
	 	}
		for(i=0;i<$hide.length;i++){
			$hide[i].style.display="none";
		}
		for(i=0;i<$hide2.length;i++){
			$hide2[i].style.display="none";
	 	}
		for(i=0;i<$hide3.length;i++){
			$hide3[i].style.display="none";
	 	}
	}

	// highlight the current gallery filter in menu
	function highlight_active($a,$b,$c,$d){
		let arr=[$a,$b,$c,$d];
		for (e= 0;e < arr.length; e ++) {
			gallery_control_option[e].style.background="none";
			gallery_control_option[e].style.color="black";
			gallery_control_option[$a].style.background="#ea5b00";
			gallery_control_option[$a].style.color="white";
		}
	}

	// display the check icon before to the orientation option
	function display_check($a,$b,$c){
		for (e= 0;e < check.length; e ++) {
			check[$a].style.display="block";
			check[$b].style.display="none";
			check[$c].style.display="none";
		}
	}
	
	// filter gallery for landscape orientation
	landscape.onclick=function(){
		display_check(1,0,2);
		orientation.style.color="#000";
		orientation.innerHTML="Landscape";
		if (current_display=="nature") {
			for (i= 0;i < nature_landscape.length; i ++) {
				nature_landscape[i].style.display="block";
				
			}
			 for (i= 0;i < nature_portrait.length; i ++) {
			 	nature_portrait[i].style.display="none";
			 }
		}
		if (current_display=="people") {
			for (i= 0;i < people_landscape.length; i ++) {
				people_landscape[i].style.display="block";

			}
			for (i= 0;i < people_portrait.length; i ++) {
				people_portrait[i].style.display="none";
			}
		}
		if (current_display=="animals") {
			for (i= 0;i < animals_landscape.length; i ++) {
				animals_landscape[i].style.display="block";
			}
			for (i= 0;i < animals_portrait.length; i ++) {
				animals_portrait[i].style.display="none";
			}
		}
		if (current_display=="home") {
			for (i= 0;i < home_landscape.length; i ++) {
				home_landscape[i].style.display="block";
			}
			for (i= 0;i < home_portrait.length; i ++) {
				home_portrait[i].style.display="none";
			}
		}
	}

	// filter gallery for portrait orientation
	portrait.onclick=function(){
		display_check(2,1,0);
		orientation.style.color="#000";
		orientation.innerHTML="Portrait";
		if (current_display=="nature") {
			for (i= 0;i < nature_landscape.length; i ++) {
				nature_landscape[i].style.display="none";
			}
			 for (i= 0;i < nature_portrait.length; i ++) {
			 	nature_portrait[i].style.display="block";
			 }
		}
		if (current_display=="people") {
			for (i= 0;i < people_landscape.length; i ++) {
				people_landscape[i].style.display="none";
			}
			for (i= 0;i < people_portrait.length; i ++) {
				people_portrait[i].style.display="block";
			}
		}
		if (current_display=="animals") {
			for (i= 0;i < animals_landscape.length; i ++) {
				animals_landscape[i].style.display="none";
			}
			for (i= 0;i < animals_portrait.length; i ++) {
				animals_portrait[i].style.display="block";
			}
		}
		if (current_display=="home") {
			for (i= 0;i < home_landscape.length; i ++) {
				home_landscape[i].style.display="none";
			}
			for (i= 0;i < home_portrait.length; i ++) {
				home_portrait[i].style.display="block";
			}
		}
	}



function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'en'}, 'google_translate_element');
}



const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
      }
    });
  });

  observer.observe(document.querySelector('#animatedBox'));







    //  slider
    $(document).ready(function() {
        $(".slider-5").slick({
            infinite: true,
            autoplay: true,
            autoplaySpeed: 1500,
            speed: 300,
            slidesToShow: 4,
            nextArrow: ".arr-next",
            prevArrow: ".arr-prev",
            slidesToScroll: 1,
            responsive: [{
                    breakpoint: 1099,
                    settings: {
                        slidesToShow: 4,
                        slidesToScroll: 1,
                        infinite: true,

                    },
                }, {
                    breakpoint: 1024,
                    settings: {
                        slidesToShow: 3,
                        slidesToScroll: 2,
                        infinite: true,

                    },
                }, {
                    breakpoint: 600,
                    settings: {
                        slidesToShow: 2,
                        slidesToScroll: 1,
                    },
                }, {
                    breakpoint: 480,
                    settings: {
                        slidesToShow: 1,
                        slidesToScroll: 1,
                    },
                },
                // You can unslick at a given breakpoint now by adding:
                // settings: "unslick"
                // instead of a settings object
            ],
        });
    });

